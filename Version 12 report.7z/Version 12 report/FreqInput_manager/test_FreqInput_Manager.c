/*****************************************************************************/
/*                            Cantata Test Script                            */
/*****************************************************************************/
/*
 *    Filename: test_FreqInput_Manager.c
 *    Author: 40017951
 *    Generated on: 08-May-2023 19:34:42
 *    Generated from: FreqInput_Manager.c
 */
/*****************************************************************************/
/* Environment Definition                                                    */
/*****************************************************************************/

#define TEST_SCRIPT_GENERATOR 2

/* Include files from software under test */
#include "../../../FreqInput_Manager.h"
#include "../../../Constants_MISRA.h"

#define CANTATA_DEFAULT_VALUE 0 /* Default value of variables & stub returns */

#include <cantpp.h>  /* Cantata Directives */
/* Local types from : FreqInput_Manager.c */
typedef struct sCCS_Frequency_Input_List
{
    sCCS_Single_Frequency_Inputs_Setup_t* single_frequency_input;
    sCCS_Multiple_Frequency_Inputs_Setup_t* multiple_frequency_input;
    sCCS_Pulse_Frequency_Inputs_Setup_t* pulse_frequency_input;
    sCCS_Pulse_Frequency_Inputs_Setup_t* fast_pulse_frequency_input;
    sCCS_Directional_Frequency_Inputs_Setup_t* directional_frequency_input;
    sCCS_Paired_Frequency_Inputs_Setup_t* paired_frequency_input;
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t* directional_dg23_frequency_input;
} sCCS_Frequency_Input_List_t;

/* pragma qas cantata testscript start */
/*****************************************************************************/
/* Global Data Definitions                                                   */
/*****************************************************************************/

/* Global Functions */
S32_t Configure_Input_Channel(U16_t IO_ID_u16, U16_t Input_Configuration_Set, Input_Config_union_t * Input_Configuration_union_p);
S32_t Read_Input_Data_With_Error(U16_t IO_ID_u16, U16_t Param_ID_u16, S32_t * Data_s32_p);
S32_t Read_Input_Data(U16_t IO_ID_u16, U16_t Param_ID_u16);
void ISOLATE_void_func_ptr_sFiltered_Data_t_p(sFiltered_Data_t * data_ptr);
extern eIO_Manager_Status_t CCS_Add_Single_Frequency_Inputs(sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr, u16 count);
extern eIO_Manager_Status_t CCS_Add_Multiple_Frequency_Inputs(sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr, u16 count);
extern eIO_Manager_Status_t CCS_Add_Pulse_Frequency_Inputs(sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr, u16 count);
extern eIO_Manager_Status_t CCS_Add_Fast_Pulse_Frequency_Inputs(sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr, u16 count);
extern eIO_Manager_Status_t CCS_Add_Directional_Frequency_Inputs(sCCS_Directional_Frequency_Inputs_Setup_t * input_setup_ptr, u16 count);
extern eIO_Manager_Status_t CCS_Add_Raw_Frequency_Input(sCCS_Raw_Frequency_Input_t * input_setup_ptr);
extern eIO_Manager_Status_t CCS_Add_Buffered_Raw_Frequency_Input(sCCS_Raw_Freq_In_CircBuff_t * input_setup_ptr);
extern eIO_Manager_Status_t CCS_Add_DG23_Directional_Frequency_Inputs(sCCS_DG23_Directional_Frequency_Inputs_Setup_t * input_setup_ptr, u16 count);
extern void CCS_Update_Frequency_Fast();
//extern void CCS_Update_Frequency_Slow();

/* Global data */
typedef struct FreqInput_Manager_av_struct { sCCS_Frequency_Input_List_t * ref_frequency_list; sCCS_Raw_Frequency_Input_t ** ref_input_raw_freq_single_fast_head_ptr; sCCS_Raw_Frequency_Input_t ** ref_input_raw_freq_single_slow_head_ptr; sCCS_Raw_Freq_In_CircBuff_t ** ref_input_raw_freq_buffered_fast_head_ptr; sCCS_Raw_Freq_In_CircBuff_t ** ref_input_raw_freq_buffered_slow_head_ptr; sCCS_Quadrature_Decode_Input_t ** ref_input_quad_dec_head_ptr; u8 * ref_freq_input_filter_init_pending; } FreqInput_Manager_av_struct;
extern FreqInput_Manager_av_struct av_FreqInput_Manager;
sCCS_Single_Frequency_Inputs_Setup_t map_input_setup_ptr[1];
const Filter_Fptr_t filter_init_functions[14] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
const Filter_Fptr_t filter_update_functions[14] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
sCCS_Frequency_Input_t map_input_ptr[1];
sCCS_Multiple_Frequency_Inputs_Setup_t map_input_setup_ptr_1[1];
sCCS_Pulse_Frequency_Inputs_Setup_t map_input_setup_ptr_2[1];
sCCS_Pulse_Frequency_Inputs_Setup_t map_input_setup_ptr_3[1];
sCCS_Directional_Frequency_Inputs_Setup_t map_input_setup_ptr_4[1];
sCCS_Raw_Frequency_Input_t map_input_setup_ptr_5[1];
sCCS_Raw_Freq_In_CircBuff_t map_input_setup_ptr_6[1];
sCCS_DG23_Directional_Frequency_Inputs_Setup_t map_input_setup_ptr_7[1];
sCCS_Raw_Freq_In_CircBuff_t map_input_raw_freq_buffered_fast_head_ptr[1];
sCCS_Raw_Freq_In_CircBuff_Element_t working_sCCS_Raw_Freq_In_CircBuff_Element_t[86];
sCCS_Raw_Frequency_Input_t map_input_raw_freq_single_fast_head_ptr[1];
struct sCCS_Raw_Frequency_Input working_struct_sCCS_Raw_Frequency_Input[1];
struct sCCS_Raw_Frequency_Input working_struct_sCCS_Raw_Frequency_Input_1[1];

/* Expected variables for global data */
typedef struct expected_FreqInput_Manager_av_struct { sCCS_Frequency_Input_List_t ref_frequency_list; sCCS_Raw_Frequency_Input_t * ref_input_raw_freq_single_fast_head_ptr; sCCS_Raw_Frequency_Input_t * ref_input_raw_freq_single_slow_head_ptr; sCCS_Raw_Freq_In_CircBuff_t * ref_input_raw_freq_buffered_fast_head_ptr; sCCS_Raw_Freq_In_CircBuff_t * ref_input_raw_freq_buffered_slow_head_ptr; sCCS_Quadrature_Decode_Input_t * ref_input_quad_dec_head_ptr; u8 ref_freq_input_filter_init_pending; } expected_FreqInput_Manager_av_struct;
expected_FreqInput_Manager_av_struct expected_av_FreqInput_Manager;
sCCS_Single_Frequency_Inputs_Setup_t expected_map_input_setup_ptr[1];
sCCS_Frequency_Input_t expected_map_input_ptr[1];
sCCS_Multiple_Frequency_Inputs_Setup_t expected_map_input_setup_ptr_1[1];
sCCS_Pulse_Frequency_Inputs_Setup_t expected_map_input_setup_ptr_2[1];
sCCS_Pulse_Frequency_Inputs_Setup_t expected_map_input_setup_ptr_3[1];
sCCS_Directional_Frequency_Inputs_Setup_t expected_map_input_setup_ptr_4[1];
sCCS_Raw_Frequency_Input_t expected_map_input_setup_ptr_5[1];
sCCS_Raw_Freq_In_CircBuff_t expected_map_input_setup_ptr_6[1];
sCCS_DG23_Directional_Frequency_Inputs_Setup_t expected_map_input_setup_ptr_7[1];
sCCS_Raw_Freq_In_CircBuff_t expected_map_input_raw_freq_buffered_fast_head_ptr[1];
sCCS_Raw_Freq_In_CircBuff_Element_t expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t[86];
sCCS_Raw_Frequency_Input_t expected_map_input_raw_freq_single_fast_head_ptr[1];
struct sCCS_Raw_Frequency_Input expected_working_struct_sCCS_Raw_Frequency_Input[1];
struct sCCS_Raw_Frequency_Input expected_working_struct_sCCS_Raw_Frequency_Input_1[1];

/* This function initialises global data to default values. This function       */
/* is called by every test case so must not contain test case specific settings */
static void initialise_global_data(){
    INITIALISE(ACCESS_VARIABLE(FreqInput_Manager, frequency_list));
    INITIALISE(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr));
    INITIALISE(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr));
    INITIALISE(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr));
    INITIALISE(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr));
    INITIALISE(ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr));
    INITIALISE(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
    /* No initialisation for const data: filter_init_functions */
    /* No initialisation for const data: filter_update_functions */
    INITIALISE(map_input_setup_ptr);
    INITIALISE(map_input_setup_ptr_1);
    INITIALISE(map_input_setup_ptr_2);
    INITIALISE(map_input_setup_ptr_3);
    INITIALISE(map_input_setup_ptr_4);
    INITIALISE(map_input_setup_ptr_5);
    INITIALISE(map_input_setup_ptr_6);
    INITIALISE(map_input_setup_ptr_7);
    INITIALISE(map_input_raw_freq_buffered_fast_head_ptr);
    INITIALISE(working_sCCS_Raw_Freq_In_CircBuff_Element_t);
    INITIALISE(map_input_raw_freq_single_fast_head_ptr);
    INITIALISE(working_struct_sCCS_Raw_Frequency_Input);
    INITIALISE(working_struct_sCCS_Raw_Frequency_Input_1);
}

/* This function copies the global data settings into expected variables for */
/* use in check_global_data(). It is called by every test case so must not   */
/* contain test case specific settings.                                      */
static void initialise_expected_global_data(){
    COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, frequency_list), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list));
    COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr));
    COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr));
    COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr));
    COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr));
    COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr));
    COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
    COPY_TO_EXPECTED(map_input_setup_ptr, expected_map_input_setup_ptr);
    COPY_TO_EXPECTED(map_input_setup_ptr_1, expected_map_input_setup_ptr_1);
    COPY_TO_EXPECTED(map_input_setup_ptr_2, expected_map_input_setup_ptr_2);
    COPY_TO_EXPECTED(map_input_setup_ptr_3, expected_map_input_setup_ptr_3);
    COPY_TO_EXPECTED(map_input_setup_ptr_4, expected_map_input_setup_ptr_4);
    COPY_TO_EXPECTED(map_input_setup_ptr_5, expected_map_input_setup_ptr_5);
    COPY_TO_EXPECTED(map_input_setup_ptr_6, expected_map_input_setup_ptr_6);
    COPY_TO_EXPECTED(map_input_setup_ptr_7, expected_map_input_setup_ptr_7);
    COPY_TO_EXPECTED(map_input_raw_freq_buffered_fast_head_ptr, expected_map_input_raw_freq_buffered_fast_head_ptr);
    COPY_TO_EXPECTED(working_sCCS_Raw_Freq_In_CircBuff_Element_t, expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t);
    COPY_TO_EXPECTED(map_input_raw_freq_single_fast_head_ptr, expected_map_input_raw_freq_single_fast_head_ptr);
    COPY_TO_EXPECTED(working_struct_sCCS_Raw_Frequency_Input, expected_working_struct_sCCS_Raw_Frequency_Input);
    COPY_TO_EXPECTED(working_struct_sCCS_Raw_Frequency_Input_1, expected_working_struct_sCCS_Raw_Frequency_Input_1);
}

/* This function checks global data against the expected values. */
static void check_global_data(){
    CHECK_MEMORY("ACCESS_VARIABLE(FreqInput_Manager, frequency_list)", &ACCESS_VARIABLE(FreqInput_Manager, frequency_list), &ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list), sizeof(ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list)));
    CHECK_ADDRESS(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr));
    CHECK_ADDRESS(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr));
    CHECK_ADDRESS(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr));
    CHECK_ADDRESS(ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr));
    CHECK_ADDRESS(ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr));
    CHECK_U_CHAR(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
    CHECK_MEMORY("map_input_setup_ptr", map_input_setup_ptr, expected_map_input_setup_ptr, sizeof(expected_map_input_setup_ptr));
    CHECK_MEMORY("map_input_setup_ptr_1", map_input_setup_ptr_1, expected_map_input_setup_ptr_1, sizeof(expected_map_input_setup_ptr_1));
    CHECK_MEMORY("map_input_setup_ptr_2", map_input_setup_ptr_2, expected_map_input_setup_ptr_2, sizeof(expected_map_input_setup_ptr_2));
    CHECK_MEMORY("map_input_setup_ptr_3", map_input_setup_ptr_3, expected_map_input_setup_ptr_3, sizeof(expected_map_input_setup_ptr_3));
    CHECK_MEMORY("map_input_setup_ptr_4", map_input_setup_ptr_4, expected_map_input_setup_ptr_4, sizeof(expected_map_input_setup_ptr_4));
    CHECK_MEMORY("map_input_setup_ptr_5", map_input_setup_ptr_5, expected_map_input_setup_ptr_5, sizeof(expected_map_input_setup_ptr_5));
    CHECK_MEMORY("map_input_setup_ptr_6", map_input_setup_ptr_6, expected_map_input_setup_ptr_6, sizeof(expected_map_input_setup_ptr_6));
    CHECK_MEMORY("map_input_setup_ptr_7", map_input_setup_ptr_7, expected_map_input_setup_ptr_7, sizeof(expected_map_input_setup_ptr_7));
    CHECK_MEMORY("map_input_raw_freq_buffered_fast_head_ptr", map_input_raw_freq_buffered_fast_head_ptr, expected_map_input_raw_freq_buffered_fast_head_ptr, sizeof(expected_map_input_raw_freq_buffered_fast_head_ptr));
    CHECK_MEMORY("working_sCCS_Raw_Freq_In_CircBuff_Element_t", working_sCCS_Raw_Freq_In_CircBuff_Element_t, expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t, sizeof(expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t));
    CHECK_MEMORY("map_input_raw_freq_single_fast_head_ptr", map_input_raw_freq_single_fast_head_ptr, expected_map_input_raw_freq_single_fast_head_ptr, sizeof(expected_map_input_raw_freq_single_fast_head_ptr));
    CHECK_MEMORY("working_struct_sCCS_Raw_Frequency_Input", working_struct_sCCS_Raw_Frequency_Input, expected_working_struct_sCCS_Raw_Frequency_Input, sizeof(expected_working_struct_sCCS_Raw_Frequency_Input));
    CHECK_MEMORY("working_struct_sCCS_Raw_Frequency_Input_1", working_struct_sCCS_Raw_Frequency_Input_1, expected_working_struct_sCCS_Raw_Frequency_Input_1, sizeof(expected_working_struct_sCCS_Raw_Frequency_Input_1));
}

/* Prototypes for test functions */
void run_tests();
void test_1(int);
void test_2(int);
void test_3(int);
void test_4(int);
void test_5(int);
void test_6(int);
void test_7(int);
void test_8(int);
void test_9(int);
void test_10(int);
void test_11(int);
void test_12(int);
void test_13(int);
void test_14(int);
void test_15(int);
void test_16(int);
void test_17(int);
void test_18(int);
void test_19(int);
void test_20(int);
void test_21(int);
void test_22(int);
void test_23(int);
void test_24(int);
void test_25(int);
void test_26(int);
void test_27(int);
void test_28(int);
void test_29(int);
void test_30(int);
void test_31(int);
void test_32(int);
void test_33(int);
void test_34(int);
void test_35(int);
void test_36(int);
void test_37(int);
void test_38(int);
void test_39(int);
void test_40(int);
void test_41(int);
void test_42(int);
void test_43(int);
void test_44(int);
void test_45(int);
void test_46(int);
void test_47(int);
void test_48(int);
void test_49(int);
void test_50(int);
void test_51(int);
void test_52(int);
void test_53(int);
void test_54(int);
void test_55(int);
void test_56(int);
void test_57(int);
void test_58(int);
void test_59(int);
void test_60(int);
void test_61(int);
void test_62(int);
void test_63(int);
void test_64(int);
void test_65(int);
void test_66(int);
void test_67(int);
void test_68(int);
void test_69(int);
void test_70(int);
void test_71(int);
void test_72(int);
void test_73(int);
void test_74(int);

/*****************************************************************************/
/* Coverage Analysis                                                         */
/*****************************************************************************/
/* Coverage Rule Set: 100% Entry Point + Statement + Call Return + Decision + MC/DC Coverage */
static void rule_set(char* cppca_sut,
                     char* cppca_context)
{
    START_TEST("COVERAGE RULE SET",
               "100% Entry Point + Statement + Call Return + Decision + MC/DC Coverage");
#ifdef CANTPP_SUBSET_DEFERRED_ANALYSIS
    TEST_SCRIPT_WARNING("Coverage Rule Set ignored in deferred analysis mode\n");
#elif CANTPP_COVERAGE_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Coverage Instrumentation has been disabled\n");
#elif CANTPP_INSTRUMENTATION_DISABLED
    TEST_SCRIPT_WARNING("Instrumentation has been disabled\n");
#else
    ANALYSIS_CHECK("100% Entry Point Coverage",
                   cppca_entrypoint_cov,
                   100.0);
    
    ANALYSIS_CHECK("100% Statement Coverage",
                   cppca_statement_cov,
                   100.0);
    
    ANALYSIS_CHECK("100% Call Return Coverage",
                   cppca_callreturn_cov,
                   100.0);
    
    ANALYSIS_CHECK("100% Decision Coverage",
                   cppca_decision_cov,
                   100.0);
    
    ANALYSIS_CHECK("100% Boolean Operand Effectiveness Coverage",
                   cppca_booleff_cov,
                   100.0);
    
    REPORT_COVERAGE(cppca_entrypoint_cov|
                    cppca_statement_cov|
                    cppca_callreturn_cov|
                    cppca_decision_cov|
                    cppca_booleff_cov,
                    cppca_sut,
                    cppca_all_details|cppca_include_catch,
                    cppca_context);
#endif
    END_TEST();
}

/*****************************************************************************/
/* Program Entry Point                                                       */
/*****************************************************************************/
int main()
{
    CONFIGURE_COVERAGE("cov:boolcomb:yes");
    OPEN_LOG("test_FreqInput_Manager.ctr", false, 100);
    START_SCRIPT("FreqInput_Manager", true);

    run_tests();

    return !END_SCRIPT(true);
}

/*****************************************************************************/
/* Test Control                                                              */
/*****************************************************************************/
/* run_tests() contains calls to the individual test cases, you can turn test*/
/* cases off by adding comments*/
void run_tests()
{
    test_1(1);
    test_2(1);
    test_3(1);
    test_4(1);
    test_5(1);
    test_6(1);
    test_7(1);
    test_8(1);
    test_9(1);
    test_10(1);
    test_11(1);
    test_12(1);
    test_13(1);
    test_14(1);
    test_15(1);
    test_16(1);
    test_17(1);
    test_18(1);
    test_19(1);
    test_20(1);
    test_21(1);
    test_22(1);
    test_23(1);
    test_24(1);
    test_25(1);
    test_26(1);
    test_27(1);
    test_28(1);
    test_29(1);
    test_30(1);
    test_31(1);
    test_32(1);
    test_33(1);
    test_34(1);
    test_35(1);
    test_36(1);
    test_37(1);
    test_38(1);
    test_39(1);
    test_40(1);
    test_41(1);
    test_42(1);
    test_43(1);
    test_44(1);
    test_45(1);
    test_46(1);
    test_47(1);
    test_48(1);
    test_49(1);
    test_50(1);
    test_51(1);
    test_52(1);
    test_53(1);
    test_54(1);
    test_55(1);
    test_56(1);
    test_57(1);
    test_58(1);
    test_59(1);
    test_60(1);
    test_61(1);
    test_62(1);
    test_63(1);
    test_64(1);
    test_65(1);
    test_66(1);
    test_67(1);
    test_68(1);
    test_69(1);
    test_70(1);
    test_71(1);
    test_72(1);
    test_73(1);
    test_74(1);

    rule_set("*", "*");
    EXPORT_COVERAGE("test_FreqInput_Manager.cov", cppca_export_replace);
}

/*****************************************************************************/
/* Test Cases                                                                */
/*****************************************************************************/

void test_1(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr = NULL;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("1: CCS_Add_Single_Frequency_Inputs",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Single_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_2(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr = (sCCS_Single_Frequency_Inputs_Setup_t*) 1U;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("2: CCS_Add_Single_Frequency_Inputs",
               "created to solve true case of input_setup_ptr != NULL_ at line number 107");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Single_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_3(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr = &map_input_setup_ptr[0];
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr[0].input_ptr = NULL;
    expected_map_input_setup_ptr[0].input_ptr = NULL;

    START_TEST("3: CCS_Add_Single_Frequency_Inputs",
               "created to solve true case of count > 0u at line number 107");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Single_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_4(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr = &map_input_setup_ptr[0];
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr[0].input_ptr = &map_input_ptr[0];
    map_input_setup_ptr[0].Channel_Id = 1;
    map_input_setup_ptr[0].next_ptr = NULL;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = &map_input_setup_ptr[0];
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    expected_map_input_setup_ptr[0].input_ptr = &map_input_ptr[0];
    expected_map_input_setup_ptr[0].Channel_Id = 1;
    expected_map_input_setup_ptr[0].next_ptr = NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = &map_input_setup_ptr[0];
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("4: CCS_Add_Single_Frequency_Inputs",
               "create to check false case of input_setup_ptr[i].input_ptr = NULL at line 111");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Single_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DUPLICATE_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_5(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Single_Frequency_Inputs_Setup_t single_frequency_input_Temp, my_Inputs_Setup2;
    sCCS_Frequency_Input_t  my_Input, my_Input2;
    sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;

    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    my_Inputs_Setup2.input_ptr = &my_Input;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).single_frequency_input=&single_frequency_input_Temp;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).single_frequency_input->Channel_Id=1;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).single_frequency_input->next_ptr=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).single_frequency_input->input_ptr=NULL;
    input_setup_ptr[0].Channel_Id = 1000;
    input_setup_ptr[0].type=1;
    input_setup_ptr[0].coeff=2;

    START_TEST("5: CCS_Add_Single_Frequency_Inputs",
               "create to check true case of status == IO_MANAGER_NO_ERROR at line 131");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#1");

            /* Call SUT */
            returnValue = CCS_Add_Single_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            CHECK_U_INT(input_setup_ptr[0].offset,9);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_6(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Single_Frequency_Inputs_Setup_t single_frequency_input_Temp, my_Inputs_Setup2;
    sCCS_Frequency_Input_t  my_Input, my_Input2;
    sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;

    my_Inputs_Setup2.input_ptr = &my_Input;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    my_Inputs_Setup2.type = FILTER_TYPE_MAX;
    my_Inputs_Setup2.coeff = FILTER_COEFF_MAX ;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).single_frequency_input=&single_frequency_input_Temp;
    single_frequency_input_Temp.input_ptr = &my_Input2;
    single_frequency_input_Temp.Channel_Id = 1;
    single_frequency_input_Temp.next_ptr = NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;

    START_TEST("6: CCS_Add_Single_Frequency_Inputs",
               "create to check coverage for lines at 145");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_Single_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            CHECK_U_INT(my_Inputs_Setup2.offset, 0U);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_7(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Single_Frequency_Inputs_Setup_t single_frequency_input_Temp, my_Inputs_Setup2;
    sCCS_Frequency_Input_t  my_Input, my_Input2;
    sCCS_Single_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;

    my_Inputs_Setup2.input_ptr = &my_Input;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    my_Inputs_Setup2.type = FILTER_TYPE_IIR;
    my_Inputs_Setup2.coeff = FILTER_COEFF_MAX ;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).single_frequency_input=&single_frequency_input_Temp;
    single_frequency_input_Temp.input_ptr = &my_Input2;
    single_frequency_input_Temp.Channel_Id = 1;
    single_frequency_input_Temp.next_ptr = NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;

    START_TEST("7: CCS_Add_Single_Frequency_Inputs",
               "create to check coverage for lines at 149");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_Single_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            CHECK_U_INT(my_Inputs_Setup2.offset, 0U);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_8(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr = NULL;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("8: CCS_Add_Multiple_Frequency_Inputs",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Multiple_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_9(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr = (sCCS_Multiple_Frequency_Inputs_Setup_t*) 1U;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("9: CCS_Add_Multiple_Frequency_Inputs",
               "created to solve true case of input_setup_ptr != NULL_ at line number 179");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Multiple_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_10(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr = &map_input_setup_ptr_1[0];
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr_1[0].input_ptr = NULL;
    expected_map_input_setup_ptr_1[0].input_ptr = NULL;

    START_TEST("10: CCS_Add_Multiple_Frequency_Inputs",
               "created to solve true case of count > 0u at line number 179");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Multiple_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_11(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Multiple_Frequency_Inputs_Setup_t multiple_frequency_input_Temp;
    sCCS_Multiple_Frequency_Inputs_Setup_t my_Inputs_Setup;
    sCCS_Frequency_Input_t  input_ptr_Temp;
    sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup.next_ptr = NULL;
    eIO_Manager_Status_t returnValue;

    input_setup_ptr[0].input_ptr=&input_ptr_Temp;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).single_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input->Channel_Id=input_setup_ptr[0].Channel_Id;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input->next_ptr=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("11: CCS_Add_Multiple_Frequency_Inputs",
               "create to check false case of input_setup_ptr[i].input_ptr = NULL at line number 183");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Multiple_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DUPLICATE_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_12(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Multiple_Frequency_Inputs_Setup_t 	multiple_frequency_input_Temp;
    sCCS_Multiple_Frequency_Inputs_Setup_t my_Inputs_Setup2;
    sCCS_Frequency_Input_t  my_Input, my_Input2;
    sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    u16 count = 1U;
    multiple_frequency_input_Temp.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    multiple_frequency_input_Temp.next_ptr = NULL;

    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    eIO_Manager_Status_t returnValue;

    input_setup_ptr[0].input_ptr=&my_Input2;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("12: CCS_Add_Multiple_Frequency_Inputs",
               "create to check false case of input_setup_ptr[i].input_ptr = NULL_ at line number 183");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#3");

            /* Call SUT */
            returnValue = CCS_Add_Multiple_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_13(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Multiple_Frequency_Inputs_Setup_t multiple_frequency_input_Temp, my_Inputs_Setup2;
    sCCS_Frequency_Input_t  my_Input, my_Input2;
    sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    multiple_frequency_input_Temp.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    multiple_frequency_input_Temp.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    multiple_frequency_input_Temp.next_ptr = NULL;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    my_Inputs_Setup2.type = FILTER_TYPE_IIR;
    my_Inputs_Setup2.coeff = FILTER_COEFF_64;
    eIO_Manager_Status_t returnValue;

    input_setup_ptr[0].input_ptr=&my_Input2;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("13: CCS_Add_Multiple_Frequency_Inputs",
               "create to check false case of input_setup_ptr[i].input_ptr = NULL_ at line number 183");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_Multiple_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            CHECK_U_INT(my_Inputs_Setup2.offset, 13u);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_14(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Multiple_Frequency_Inputs_Setup_t multiple_frequency_input_Temp, my_Inputs_Setup2;
    sCCS_Frequency_Input_t  my_Input, my_Input2;
    sCCS_Multiple_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    multiple_frequency_input_Temp.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    multiple_frequency_input_Temp.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    multiple_frequency_input_Temp.next_ptr = NULL;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    my_Inputs_Setup2.type = FILTER_TYPE_IIR;
    my_Inputs_Setup2.coeff = FILTER_COEFF_MAX;
    eIO_Manager_Status_t returnValue;

    input_setup_ptr[0].input_ptr=&my_Input2;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=&multiple_frequency_input_Temp;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("14: CCS_Add_Multiple_Frequency_Inputs",
               "create to check false case of input_setup_ptr[i].input_ptr = NULL_ at line number 183");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_Multiple_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            CHECK_U_INT(my_Inputs_Setup2.offset, 0u);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_15(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = NULL;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("15: CCS_Add_Pulse_Frequency_Inputs",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_16(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = (sCCS_Pulse_Frequency_Inputs_Setup_t*) 1U;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("16: CCS_Add_Pulse_Frequency_Inputs",
               "created to solve true case of input_setup_ptr != NULL_ at line number 250");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_17(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &map_input_setup_ptr_2[0];
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr_2[0].input_ptr = NULL;
    expected_map_input_setup_ptr_2[0].input_ptr = NULL;

    START_TEST("17: CCS_Add_Pulse_Frequency_Inputs",
               "created to solve true case of count > 0u at line number 250");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_18(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t my_Inputs_Setup;
    sCCS_Pulse_Frequency_Inputs_t  my_Input;
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup;
    my_Inputs_Setup.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup.next_ptr = NULL;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("18: CCS_Add_Pulse_Frequency_Inputs",
               "create to check false case of input._setup_ptr[i].input_ptr = NULL at line 254");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DUPLICATE_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_19(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Pulse_Frequency_Inputs_t  my_Input, my_Input2;
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Inputs_Setup2;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("19: CCS_Add_Pulse_Frequency_Inputs",
               "create to check true case of status == IO_MANAGER_NO_ERROR at line 273");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#1");

            /* Call SUT */
            returnValue = CCS_Add_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_20(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Pulse_Frequency_Inputs_t my_Input, my_Input2;
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Inputs_Setup2;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("20: CCS_Add_Pulse_Frequency_Inputs",
               "create to check coverage for line at line 287");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_21(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = NULL;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("21: CCS_Add_Fast_Pulse_Frequency_Inputs",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Fast_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_22(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = (sCCS_Pulse_Frequency_Inputs_Setup_t*) 1U;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("22: CCS_Add_Fast_Pulse_Frequency_Inputs",
               "created to solve true case of input_setup_ptr != NULL_ at line number 311");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Fast_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_23(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &map_input_setup_ptr_3[0];
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr_3[0].input_ptr = NULL;
    expected_map_input_setup_ptr_3[0].input_ptr = NULL;

    START_TEST("23: CCS_Add_Fast_Pulse_Frequency_Inputs",
               "created to solve true case of count > 0u at line number 311");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Fast_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_24(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t my_Inputs_Setup;
    sCCS_Pulse_Frequency_Inputs_t  my_Input;
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup;
    my_Inputs_Setup.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup.next_ptr = NULL;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("24: CCS_Add_Fast_Pulse_Frequency_Inputs",
               "create to check false case of input._setup_ptr[i].input_ptr = NULL at line number 315");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Fast_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DUPLICATE_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_25(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Pulse_Frequency_Inputs_t  my_Input, my_Input2;
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &my_Inputs_Setup2;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("25: CCS_Add_Fast_Pulse_Frequency_Inputs",
               "create to check true case of status == IO_MANAGER_NO_ERROR at line number 334");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#1");

            /* Call SUT */
            returnValue = CCS_Add_Fast_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_26(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Pulse_Frequency_Inputs_t my_Input, my_Input2;
    sCCS_Pulse_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;
    my_Inputs_Setup2.Max_Frequency_u16 = 0x1;
    my_Inputs_Setup2.Edge_Polarity_u8 = 0x2;
    my_Inputs_Setup2.Zero_Speed_Frequency_Timeout_u16 = 0x3;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &my_Inputs_Setup2;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("26: CCS_Add_Fast_Pulse_Frequency_Inputs",
               "create to check coverage for line at line 348");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_Fast_Pulse_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_27(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = NULL;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("27: CCS_Add_Directional_Frequency_Inputs",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_28(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = (sCCS_Directional_Frequency_Inputs_Setup_t*) 1U;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("28: CCS_Add_Directional_Frequency_Inputs",
               "created to solve true case of input_setup_ptr != NULL_ at line number 372");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_29(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &map_input_setup_ptr_4[0];
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr_4[0].input_ptr = NULL;
    expected_map_input_setup_ptr_4[0].input_ptr = NULL;

    START_TEST("29: CCS_Add_Directional_Frequency_Inputs",
               "created to solve true case of count > 0u at line number 372");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_30(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Directional_Frequency_Inputs_Setup_t my_Inputs_Setup;
    sCCS_Directional_Frequency_Inputs_t  my_Input;
    sCCS_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup;
    my_Inputs_Setup.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup.next_ptr = NULL;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Inputs_Setup;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Inputs_Setup;

    START_TEST("30: CCS_Add_Directional_Frequency_Inputs",
               "create to check false case of input_setup_ptr[i].input_ptr = NULL at line 376");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DUPLICATE_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_31(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Directional_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Directional_Frequency_Inputs_t  my_Input, my_Input2;
    sCCS_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    eIO_Manager_Status_t returnValue;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;
    my_Inputs_Setup2.Physical_Input1_ID = 1;
    my_Inputs_Setup2.Air_Gap_Width_u16 = 2;
    my_Inputs_Setup2.Air_Gap_Tolerance_u16 = 3;
    my_Inputs_Setup2.Stand_Still_Period_u16 = 4;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Inputs_Setup;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Inputs_Setup2;

    START_TEST("31: CCS_Add_Directional_Frequency_Inputs",
               "create to check true case of status == IO_MANAGER_NO_ERROR at line 395");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#4");

            /* Call SUT */
            returnValue = CCS_Add_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_32(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Directional_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Directional_Frequency_Inputs_t my_Input, my_Input2;
    sCCS_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    eIO_Manager_Status_t returnValue;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;

	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Inputs_Setup;

	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Inputs_Setup2;

    START_TEST("32: CCS_Add_Directional_Frequency_Inputs",
               "create to check true case of status == IO_MANAGER_NO_ERROR at line 395");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_33(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Frequency_Input_t * input_setup_ptr = NULL;
    eIO_Manager_Status_t returnValue;

    START_TEST("33: CCS_Add_Raw_Frequency_Input",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_34(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Frequency_Input_t * input_setup_ptr = &map_input_setup_ptr_5[0];
    eIO_Manager_Status_t returnValue;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
    map_input_setup_ptr_5[0].set_id = 0U;
    map_input_setup_ptr_5[0].channel_id = 0U;
    map_input_setup_ptr_5[0].zero_speed_frequency_timeout_u16 = 0U;
    map_input_setup_ptr_5[0].edge_polarity_setup = 85U;
    map_input_setup_ptr_5[0].fast_update = 85U;
    expected_map_input_setup_ptr_5[0].set_id = 0U;
    expected_map_input_setup_ptr_5[0].channel_id = 0U;
    expected_map_input_setup_ptr_5[0].zero_speed_frequency_timeout_u16 = 0U;
    expected_map_input_setup_ptr_5[0].edge_polarity_setup = 85U;
    expected_map_input_setup_ptr_5[0].fast_update = 85U;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = &map_input_setup_ptr_5[0];
    expected_map_input_setup_ptr_5[0].next_ptr = NULL;

    START_TEST("34: CCS_Add_Raw_Frequency_Input",
               "created to solve true case of input_setup_ptr != NULL_ at line number 557");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#5");

            /* Call SUT */
            returnValue = CCS_Add_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_35(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Frequency_Input_t * input_setup_ptr = &map_input_setup_ptr_5[0];
    eIO_Manager_Status_t returnValue;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
    map_input_setup_ptr_5[0].set_id = 0U;
    map_input_setup_ptr_5[0].channel_id = 0U;
    map_input_setup_ptr_5[0].zero_speed_frequency_timeout_u16 = 0U;
    map_input_setup_ptr_5[0].edge_polarity_setup = 85U;
    map_input_setup_ptr_5[0].fast_update = 85U;
    expected_map_input_setup_ptr_5[0].set_id = 0U;
    expected_map_input_setup_ptr_5[0].channel_id = 0U;
    expected_map_input_setup_ptr_5[0].zero_speed_frequency_timeout_u16 = 0U;
    expected_map_input_setup_ptr_5[0].edge_polarity_setup = 85U;
    expected_map_input_setup_ptr_5[0].fast_update = 85U;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = &map_input_setup_ptr_5[0];
    expected_map_input_setup_ptr_5[0].next_ptr = NULL;

    START_TEST("35: CCS_Add_Raw_Frequency_Input",
               "created to solve true case of Configure_Input_Channel(input_setup_ptr->set_id, (u16)IO_SET_FREQUENCY, &input_config) != IO_SUCCESS at line number 576");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#6");

            /* Call SUT */
            returnValue = CCS_Add_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_36(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Frequency_Input_t * input_setup_ptr = &map_input_setup_ptr_5[0];
    eIO_Manager_Status_t returnValue;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
    map_input_setup_ptr_5[0].set_id = 0U;
    map_input_setup_ptr_5[0].channel_id = 0U;
    map_input_setup_ptr_5[0].zero_speed_frequency_timeout_u16 = 0U;
    map_input_setup_ptr_5[0].edge_polarity_setup = 85U;
    map_input_setup_ptr_5[0].fast_update = 0U;
    expected_map_input_setup_ptr_5[0].set_id = 0U;
    expected_map_input_setup_ptr_5[0].channel_id = 0U;
    expected_map_input_setup_ptr_5[0].zero_speed_frequency_timeout_u16 = 0U;
    expected_map_input_setup_ptr_5[0].edge_polarity_setup = 85U;
    expected_map_input_setup_ptr_5[0].fast_update = 0U;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = &map_input_setup_ptr_5[0];
    expected_map_input_setup_ptr_5[0].next_ptr = NULL;

    START_TEST("36: CCS_Add_Raw_Frequency_Input",
               "created to solve false case of input_setup_ptr->fast_update != FALSE at line number 559");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#5");

            /* Call SUT */
            returnValue = CCS_Add_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_37(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Freq_In_CircBuff_t * input_setup_ptr = NULL;
    eIO_Manager_Status_t returnValue;

    START_TEST("37: CCS_Add_Buffered_Raw_Frequency_Input",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Buffered_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_38(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Freq_In_CircBuff_t * input_setup_ptr = &map_input_setup_ptr_6[0];
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr_6[0].circ_buff = NULL;
    expected_map_input_setup_ptr_6[0].circ_buff = NULL;

    START_TEST("38: CCS_Add_Buffered_Raw_Frequency_Input",
               "created to solve true case of input_setup_ptr != NULL_ at line number 596");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Buffered_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_39(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Freq_In_CircBuff_t * input_setup_ptr = &map_input_setup_ptr_6[0];
    eIO_Manager_Status_t returnValue;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    map_input_setup_ptr_6[0].set_id = 0U;
    map_input_setup_ptr_6[0].channel_id = 0U;
    map_input_setup_ptr_6[0].zero_speed_frequency_timeout_u16 = 0U;
    map_input_setup_ptr_6[0].edge_polarity_setup = 85U;
    map_input_setup_ptr_6[0].fast_update = 85U;
    map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    map_input_setup_ptr_6[0].circ_buff_size = 85U;
    expected_map_input_setup_ptr_6[0].set_id = 0U;
    expected_map_input_setup_ptr_6[0].channel_id = 0U;
    expected_map_input_setup_ptr_6[0].zero_speed_frequency_timeout_u16 = 0U;
    expected_map_input_setup_ptr_6[0].edge_polarity_setup = 85U;
    expected_map_input_setup_ptr_6[0].fast_update = 85U;
    expected_map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    expected_map_input_setup_ptr_6[0].circ_buff_size = 85U;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = &map_input_setup_ptr_6[0];
    expected_map_input_setup_ptr_6[0].circ_buff_head = 0U;
    expected_map_input_setup_ptr_6[0].circ_buff_tail = 0U;
    expected_map_input_setup_ptr_6[0].next_ptr = NULL;

    START_TEST("39: CCS_Add_Buffered_Raw_Frequency_Input",
               "created to solve true case of input_setup_ptr->circ_buff != NULL_ at line number 598");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#7");

            /* Call SUT */
            returnValue = CCS_Add_Buffered_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_40(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Freq_In_CircBuff_t * input_setup_ptr = &map_input_setup_ptr_6[0];
    eIO_Manager_Status_t returnValue;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    map_input_setup_ptr_6[0].set_id = 0U;
    map_input_setup_ptr_6[0].channel_id = 0U;
    map_input_setup_ptr_6[0].zero_speed_frequency_timeout_u16 = 0U;
    map_input_setup_ptr_6[0].edge_polarity_setup = 85U;
    map_input_setup_ptr_6[0].fast_update = 85U;
    map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    map_input_setup_ptr_6[0].circ_buff_size = 85U;
    expected_map_input_setup_ptr_6[0].set_id = 0U;
    expected_map_input_setup_ptr_6[0].channel_id = 0U;
    expected_map_input_setup_ptr_6[0].zero_speed_frequency_timeout_u16 = 0U;
    expected_map_input_setup_ptr_6[0].edge_polarity_setup = 85U;
    expected_map_input_setup_ptr_6[0].fast_update = 85U;
    expected_map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    expected_map_input_setup_ptr_6[0].circ_buff_size = 85U;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = &map_input_setup_ptr_6[0];
    expected_map_input_setup_ptr_6[0].circ_buff_head = 0U;
    expected_map_input_setup_ptr_6[0].circ_buff_tail = 0U;
    expected_map_input_setup_ptr_6[0].next_ptr = NULL;

    START_TEST("40: CCS_Add_Buffered_Raw_Frequency_Input",
               "created to solve true case of Configure_Input_Channel(input_setup_ptr->set_id, (u16)IO_SET_FREQUENCY, &input_config) != IO_SUCCESS at line number 620");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#8");

            /* Call SUT */
            returnValue = CCS_Add_Buffered_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_41(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Freq_In_CircBuff_t * input_setup_ptr = &map_input_setup_ptr_6[0];
    eIO_Manager_Status_t returnValue;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
    map_input_setup_ptr_6[0].set_id = 0U;
    map_input_setup_ptr_6[0].channel_id = 0U;
    map_input_setup_ptr_6[0].zero_speed_frequency_timeout_u16 = 0U;
    map_input_setup_ptr_6[0].edge_polarity_setup = 85U;
    map_input_setup_ptr_6[0].fast_update = 0U;
    map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    map_input_setup_ptr_6[0].circ_buff_size = 85U;
    expected_map_input_setup_ptr_6[0].set_id = 0U;
    expected_map_input_setup_ptr_6[0].channel_id = 0U;
    expected_map_input_setup_ptr_6[0].zero_speed_frequency_timeout_u16 = 0U;
    expected_map_input_setup_ptr_6[0].edge_polarity_setup = 85U;
    expected_map_input_setup_ptr_6[0].fast_update = 0U;
    expected_map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    expected_map_input_setup_ptr_6[0].circ_buff_size = 85U;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = &map_input_setup_ptr_6[0];
    expected_map_input_setup_ptr_6[0].circ_buff_head = 0U;
    expected_map_input_setup_ptr_6[0].circ_buff_tail = 0U;
    expected_map_input_setup_ptr_6[0].next_ptr = NULL;

    START_TEST("41: CCS_Add_Buffered_Raw_Frequency_Input",
               "created to solve false case of input_setup_ptr->fast_update != FALSE at line number 600");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#7");

            /* Call SUT */
            returnValue = CCS_Add_Buffered_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_42(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Raw_Freq_In_CircBuff_t * input_setup_ptr = &map_input_setup_ptr_6[0];
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    map_input_setup_ptr_6[0].circ_buff_size = 0U;
    expected_map_input_setup_ptr_6[0].circ_buff = (sCCS_Raw_Freq_In_CircBuff_Element_t*) 1U;
    expected_map_input_setup_ptr_6[0].circ_buff_size = 0U;

    START_TEST("42: CCS_Add_Buffered_Raw_Frequency_Input",
               "created to solve false case of input_setup_ptr->circ_buff_size != 0u at line number 598");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_Buffered_Raw_Frequency_Input(input_setup_ptr);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_43(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = NULL;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("43: CCS_Add_DG23_Directional_Frequency_Inputs",
               "default case");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_DG23_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_44(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = (sCCS_DG23_Directional_Frequency_Inputs_Setup_t*) 1U;
    u16 count = 0U;
    eIO_Manager_Status_t returnValue;

    START_TEST("44: CCS_Add_DG23_Directional_Frequency_Inputs",
               "created to solve true case of input_setup_ptr != NULL_ at line number 953");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_DG23_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_LIST);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_45(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &map_input_setup_ptr_7[0];
    u16 count = 1U;
    eIO_Manager_Status_t returnValue;
    map_input_setup_ptr_7[0].input_ptr = NULL;
    expected_map_input_setup_ptr_7[0].input_ptr = NULL;

    START_TEST("45: CCS_Add_DG23_Directional_Frequency_Inputs",
               "created to solve true case of count > 0u at line number 953");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_DG23_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_46(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t my_Inputs_Setup;
    sCCS_Directional_Frequency_Inputs_t  my_Input;
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup;
    my_Inputs_Setup.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup.next_ptr = NULL;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = &my_Inputs_Setup;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = &my_Inputs_Setup;

    START_TEST("46: CCS_Add_DG23_Directional_Frequency_Inputs",
               "create to check false case of input_setup_ptr[i].input_ptr = NULL at line 957");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("");

            /* Call SUT */
            returnValue = CCS_Add_DG23_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DUPLICATE_INPUT);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_47(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Directional_Frequency_Inputs_t  my_Input, my_Input2;
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;
    my_Inputs_Setup2.Physical_Input1_ID = 0;
    my_Inputs_Setup2.Forward_Pulse_u8 = 0x2;
    my_Inputs_Setup2.Pulse_Tolerance_u8 = 0x3;
    my_Inputs_Setup2.Max_Period_u16 = 0;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = &my_Inputs_Setup2;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("47: CCS_Add_DG23_Directional_Frequency_Inputs",
               "create to check true case of status == IO_MANAGER_NO_ERROR at line number 976");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#9");

            /* Call SUT */
            returnValue = CCS_Add_DG23_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_NO_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_48(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t my_Inputs_Setup, my_Inputs_Setup2;
    sCCS_Directional_Frequency_Inputs_t  my_Input, my_Input2;
    sCCS_DG23_Directional_Frequency_Inputs_Setup_t * input_setup_ptr = &my_Inputs_Setup2;
    my_Inputs_Setup.input_ptr = &my_Input2;
    my_Inputs_Setup2.input_ptr = &my_Input;
    u16 count = 1U;
    my_Inputs_Setup.Channel_Id = 1;
    my_Inputs_Setup2.Channel_Id = 2;
    my_Inputs_Setup.next_ptr = NULL;
    my_Inputs_Setup2.Physical_Input1_ID = 0;
    my_Inputs_Setup2.Forward_Pulse_u8 = 0x2;
    my_Inputs_Setup2.Pulse_Tolerance_u8 = 0x3;
    my_Inputs_Setup2.Max_Period_u16 = 0;
    eIO_Manager_Status_t returnValue;

    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = &my_Inputs_Setup;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_VARIABLE(FreqInput_Manager,frequency_list).paired_frequency_input=NULL;

    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = &my_Inputs_Setup2;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).directional_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).multiple_frequency_input=NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,frequency_list).pulse_frequency_input=NULL;

    START_TEST("48: CCS_Add_DG23_Directional_Frequency_Inputs",
               "create to check true case of status == IO_MANAGER_NO_ERROR at line number 976");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Configure_Input_Channel#2");

            /* Call SUT */
            returnValue = CCS_Add_DG23_Directional_Frequency_Inputs(input_setup_ptr, count);

            /* Test case checks */
            CHECK_S_INT(returnValue, IO_MANAGER_DRIVER_ERROR);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_49(int doIt){
if (doIt) {
	/* Set global data */
	initialise_global_data();
	/* Set expected values for global data checks */
	initialise_expected_global_data();
	{
	/* Test case data declarations */
	ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
	ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;
	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;

	START_TEST("49: CCS_Update_Frequency_Fast",
	               "default case");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("");

	            /* Call SUT */
	            CCS_Update_Frequency_Fast();

	            /* Test case checks */
	            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input /* Set expected to actual value as value is not known*/;
	            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
	            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
	            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input /* Set expected to actual value as value is not known*/;
	            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
	            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
	            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
	            /* Checks on global data */
	            check_global_data();
	        END_CALLS();
	END_TEST();
}}}

void test_50(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = &map_input_raw_freq_buffered_fast_head_ptr[0];
    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;
    map_input_raw_freq_buffered_fast_head_ptr[0].set_id = 0U;
    map_input_raw_freq_buffered_fast_head_ptr[0].circ_buff = &working_sCCS_Raw_Freq_In_CircBuff_Element_t[0];
    map_input_raw_freq_buffered_fast_head_ptr[0].circ_buff_size = 2U;
    map_input_raw_freq_buffered_fast_head_ptr[0].circ_buff_head = 85U;
    map_input_raw_freq_buffered_fast_head_ptr[0].next_ptr = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
    expected_map_input_raw_freq_buffered_fast_head_ptr[0].set_id = 0U;
    expected_map_input_raw_freq_buffered_fast_head_ptr[0].circ_buff_size = 2U;
    expected_map_input_raw_freq_buffered_fast_head_ptr[0].next_ptr = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = &map_input_raw_freq_buffered_fast_head_ptr[0];
    expected_map_input_raw_freq_buffered_fast_head_ptr[0].circ_buff = &working_sCCS_Raw_Freq_In_CircBuff_Element_t[0];
    expected_map_input_raw_freq_buffered_fast_head_ptr[0].circ_buff_head = 0U;
    expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t[0].edge_polarity = 0U;
    expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t[0].edge_time_stamp_us = 0UL;
    expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t[1].edge_polarity = 0U;
    expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t[1].edge_time_stamp_us = 0UL;
    expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t[85].edge_polarity = 0U;
    expected_working_sCCS_Raw_Freq_In_CircBuff_Element_t[85].edge_time_stamp_us = 0UL;
	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;

    START_TEST("50: CCS_Update_Frequency_Fast",
               "created to solve false case of IO_SUCCESS == Read_Input_Data_With_Error(input_raw_freq_buffered_ptr->set_id, IO_PARAM_EDGES_DATA, (S32_t *) &value) at line number 716");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Read_Input_Data_With_Error#1;Read_Input_Data_With_Error#2;Read_Input_Data_With_Error#2;Read_Input_Data_With_Error#3");

            /* Call SUT */
            CCS_Update_Frequency_Fast();

            /* Test case checks */
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_51(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = &map_input_raw_freq_single_fast_head_ptr[0];
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;
    map_input_raw_freq_single_fast_head_ptr[0].set_id = 0U;
    map_input_raw_freq_single_fast_head_ptr[0].next_ptr = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    expected_map_input_raw_freq_single_fast_head_ptr[0].set_id = 0U;
    expected_map_input_raw_freq_single_fast_head_ptr[0].next_ptr = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = &map_input_raw_freq_single_fast_head_ptr[0];
    expected_map_input_raw_freq_single_fast_head_ptr[0].new_data_available = 1U;
    expected_map_input_raw_freq_single_fast_head_ptr[0].edge_polarity = 0U;
    expected_map_input_raw_freq_single_fast_head_ptr[0].edge_time_stamp_us = 0UL;
	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;

    START_TEST("51: CCS_Update_Frequency_Fast",
               "created to solve true case of input_raw_freq_single_ptr != NULL_ at line number 689");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Read_Input_Data_With_Error#1");

            /* Call SUT */
            CCS_Update_Frequency_Fast();

            /* Test case checks */
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_52(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = &map_input_raw_freq_single_fast_head_ptr[0];
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;
    map_input_raw_freq_single_fast_head_ptr[0].set_id = 0U;
    map_input_raw_freq_single_fast_head_ptr[0].next_ptr = &working_struct_sCCS_Raw_Frequency_Input[0];
    working_struct_sCCS_Raw_Frequency_Input[0].set_id = 0U;
    working_struct_sCCS_Raw_Frequency_Input[0].next_ptr = &working_struct_sCCS_Raw_Frequency_Input_1[0];
    working_struct_sCCS_Raw_Frequency_Input_1[0].set_id = 0U;
    working_struct_sCCS_Raw_Frequency_Input_1[0].next_ptr = &working_struct_sCCS_Raw_Frequency_Input_1[0];
    working_struct_sCCS_Raw_Frequency_Input_1[0].next_ptr = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    expected_map_input_raw_freq_single_fast_head_ptr[0].set_id = 0U;
    expected_working_struct_sCCS_Raw_Frequency_Input[0].set_id = 0U;
    expected_working_struct_sCCS_Raw_Frequency_Input_1[0].set_id = 0U;
    expected_working_struct_sCCS_Raw_Frequency_Input_1[0].set_id = 0U;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = &map_input_raw_freq_single_fast_head_ptr[0];
    expected_map_input_raw_freq_single_fast_head_ptr[0].new_data_available = 1U;
    expected_map_input_raw_freq_single_fast_head_ptr[0].edge_polarity = 0U;
    expected_map_input_raw_freq_single_fast_head_ptr[0].edge_time_stamp_us = 0UL;
    expected_map_input_raw_freq_single_fast_head_ptr[0].next_ptr = &working_struct_sCCS_Raw_Frequency_Input[0];
    expected_working_struct_sCCS_Raw_Frequency_Input[0].next_ptr = &working_struct_sCCS_Raw_Frequency_Input_1[0];
    expected_working_struct_sCCS_Raw_Frequency_Input_1[0].next_ptr = &working_struct_sCCS_Raw_Frequency_Input_1[0];
    expected_working_struct_sCCS_Raw_Frequency_Input_1[0].next_ptr = NULL;
	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = NULL;

	START_TEST("52: CCS_Update_Frequency_Fast",
               "created to solve false case of input_raw_freq_single_ptr != NULL_ at line number 689");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Read_Input_Data_With_Error#1;Read_Input_Data_With_Error#3;Read_Input_Data_With_Error#3");

            /* Call SUT */
            CCS_Update_Frequency_Fast();

            /* Test case checks */
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_53(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    sCCS_Pulse_Frequency_Inputs_t my_Input;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &map_input_setup_ptr_2[0];
    map_input_setup_ptr_2[0].next_ptr = NULL;
    map_input_setup_ptr_2[0].input_ptr = &my_Input;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_fast_head_ptr) = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_fast_head_ptr) = NULL;
    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).fast_pulse_frequency_input = &map_input_setup_ptr_2[0];
    expected_map_input_setup_ptr_2[0].next_ptr = NULL;
    expected_map_input_setup_ptr_2[0].input_ptr = &my_Input;

	START_TEST("53: CCS_Update_Frequency_Fast",
	           "created to solve true case of fast_pulse_freq_list_ptr != NULL_ at line number 735");

        /* Expected Call Sequence  */
        EXPECTED_CALLS("Read_Input_Data#default");

            /* Call SUT */
            CCS_Update_Frequency_Fast();

            /* Test case checks */
            CHECK_U_INT(my_Input.Pulse_Count_u16, 0);
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input /* Set expected to actual value as value is not known*/;
            ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input /* Set expected to actual value as value is not known*/;
            /* Checks on global data */
            check_global_data();
        END_CALLS();
    END_TEST();
}}}

void test_54(int doIt){
if (doIt) {
    /* Set global data */
    initialise_global_data();
    /* Set expected values for global data checks */
    initialise_expected_global_data();
    {
    /* Test case data declarations */
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = NULL;

    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
    	ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = NULL;

    	START_TEST("54: CCS_Update_Frequency_Slow",
    			"default case");

    	/* Expected Call Sequence  */
    	EXPECTED_CALLS("");

    	/* Call SUT */
    	CCS_Update_Frequency_Slow();

    	/* Test case checks */
    	/* Checks on global data */
    	check_global_data();
    	END_CALLS();
    END_TEST();
}}}

void test_55(int doIt){
if (doIt) {
		/* Test case data declarations */
		sCCS_Single_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Frequency_Input_t my_Input;
		/* Set global data */
		initialise_global_data();
		ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = &my_Input_Setup;
		my_Input_Setup.input_ptr = &my_Input;
		my_Input_Setup.offset = 0;
		my_Input_Setup.next_ptr = NULL;

		ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
		ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
		ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
		ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
		ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
		ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
		ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
		ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

		/* Set expected values for global data checks */
		initialise_expected_global_data();
		ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

		START_TEST("55: CCS_Update_Frequency_Slow",
				"single_freq_list_ptr != NULL  and pending");

		/* Expected Call Sequence  */
		EXPECTED_CALLS("Read_Input_Data#1;ISOLATE_void_func_ptr_sFiltered_Data_t_p#1");

			/* Call SUT */
			CCS_Update_Frequency_Slow();

			/* Test case checks */
			CHECK_U_INT(my_Input.Freq_Hz_Raw_u32, 1);

			/* Checks on global data */
			check_global_data();
			CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
		END_CALLS();
	END_TEST();
}}

void test_56(int doIt){
if (doIt) {
	    /* Test case data declarations */
		sCCS_Single_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Frequency_Input_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = &my_Input_Setup;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.offset = 0;
	    my_Input_Setup.next_ptr = NULL;

	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("56: CCS_Update_Frequency_Slow",
	               "single_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1;ISOLATE_void_func_ptr_sFiltered_Data_t_p#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Raw_u32, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_57(int doIt){
if (doIt) {
	    /* Test case data declarations */
		sCCS_Single_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Frequency_Input_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = &my_Input_Setup;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.offset = 0;
	    my_Input_Setup.next_ptr = NULL;

	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("57: CCS_Update_Frequency_Slow",
	               "single_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1;ISOLATE_void_func_ptr_sFiltered_Data_t_p#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Raw_u32, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_58(int doIt){
if (doIt) {
	    /* Test case data declarations */
		sCCS_Multiple_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Frequency_Input_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.offset = 0;
	    my_Input_Setup.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = &my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("58: CCS_Update_Frequency_Slow",
	               "multiple_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1;ISOLATE_void_func_ptr_sFiltered_Data_t_p#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Raw_u32, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_59(int doIt){
if (doIt) {
	    /* Test case data declarations */
		sCCS_Pulse_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Pulse_Frequency_Inputs_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.next_ptr = NULL;

	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();
	    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    START_TEST("59: CCS_Update_Frequency_Slow",
	               "pulse_freq_list_ptr != NULL  and pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Pulse_Count_u16, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_60(int doIt){
if (doIt) {
	    /* Test case data declarations */
		sCCS_Pulse_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Pulse_Frequency_Inputs_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = &my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("60: CCS_Update_Frequency_Slow",
	               "pulse_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Pulse_Count_u16, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_61(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Directional_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Directional_Frequency_Inputs_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();
	    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    START_TEST("61: CCS_Update_Frequency_Slow",
	               "directional_freq_list_ptr != NULL  and pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1;Read_Input_Data#1;Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Filtered_s32, 1);
	            CHECK_U_INT(my_Input.Sensor_Status_u16, 1);
	            CHECK_U_INT(my_Input.Direction_Status_u16, 1);
	            COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
	            /* Checks on global data */
	            check_global_data();
	        END_CALLS();
	    END_TEST();
}}

void test_62(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Directional_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Directional_Frequency_Inputs_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.next_ptr = NULL;

	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = &my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("62: CCS_Update_Frequency_Slow",
	               "directional_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	    EXPECTED_CALLS("Read_Input_Data#1;Read_Input_Data#1;Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Filtered_s32, 1);
	            CHECK_U_INT(my_Input.Sensor_Status_u16, 1);
	            CHECK_U_INT(my_Input.Direction_Status_u16, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_63(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Paired_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Paired_Frequency_Inputs_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = &my_Input_Setup;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("63: CCS_Update_Frequency_Slow",
	               "paired_freq_list_ptr != NULL  and pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1;Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Raw_u32, 1);
	            CHECK_U_INT(my_Input.Shaft_Angle_Filtered_s32, 1);
	            COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_64(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Paired_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Paired_Frequency_Inputs_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = &my_Input_Setup;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("64: CCS_Update_Frequency_Slow",
	               "paired_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	    	EXPECTED_CALLS("Read_Input_Data#1;Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Raw_u32, 1);
	            CHECK_U_INT(my_Input.Shaft_Angle_Filtered_s32, 1);
	            //CHECK_U_INT(my_Input.Shaft_Angle_Raw_s32, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_65(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		/* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("65: CCS_Update_Frequency_Slow",
	               "damper_torque_freq_list_ptr != NULL  and pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_66(int doIt){
	if (doIt) {
	    /* Test case data declarations */
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("66: CCS_Update_Frequency_Slow",
	               "damper_torque_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	    		EXPECTED_CALLS("");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_67(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Raw_Frequency_Input_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = &my_Input;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("67: CCS_Update_Frequency_Slow",
	               "input_raw_freq_single_ptr != NULL  and pending");

	        /* Expected Call Sequence  */
		EXPECTED_CALLS("Read_Input_Data_With_Error#4");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.new_data_available, TRUE);
	            CHECK_U_INT(my_Input.edge_polarity, 1);
	            CHECK_U_INT(my_Input.edge_time_stamp_us, 2);
	            COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_68(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Raw_Frequency_Input_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = &my_Input;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("68: CCS_Update_Frequency_Slow",
	               "input_raw_freq_single_ptr != NULL  and not pending");

	        /* Expected Call Sequence  */
				EXPECTED_CALLS("Read_Input_Data_With_Error#5");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_69(int doIt){
	if (doIt) {

	    /* Test case data declarations */
		sCCS_Raw_Freq_In_CircBuff_Element_t my_CircBuff[2];
		sCCS_Raw_Freq_In_CircBuff_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = &my_Input;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->circ_buff_head = 0;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->circ_buff_size = 1;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->circ_buff = &my_CircBuff[0];

	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("69: CCS_Update_Frequency_Slow",
	               "input_raw_freq_buffered_ptr != NULL  and pending");

	        /* Expected Call Sequence  */
			EXPECTED_CALLS("Read_Input_Data_With_Error#4;Read_Input_Data_With_Error#5");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.circ_buff[0].edge_polarity, 1);
	            CHECK_U_INT(my_Input.circ_buff[0].edge_time_stamp_us, 2);
	            COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_70(int doIt){
	if (doIt) {

	    /* Test case data declarations */
		sCCS_Raw_Freq_In_CircBuff_Element_t my_CircBuff[2];
		sCCS_Raw_Freq_In_CircBuff_t my_Input;
		sCCS_Raw_Frequency_Input_t my_Input_1;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = & my_Input;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->circ_buff_head = 0;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->circ_buff_size = 2;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr)->circ_buff = &my_CircBuff[0];
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("70: CCS_Update_Frequency_Slow",
	               "input_raw_freq_buffered_ptr != NULL  and not pending");

	        /* Expected Call Sequence  */
			EXPECTED_CALLS("Read_Input_Data_With_Error#4;Read_Input_Data_With_Error#5");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_71(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Quadrature_Decode_Input_t *my_Input_Setup;
		sCCS_Quadrature_Decode_Input_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup = &my_Input;
	    my_Input_Setup->next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("71: CCS_Update_Frequency_Slow",
	               "input_quad_dec_ptr != NULL  and pending");

	        /* Expected Call Sequence  */
			EXPECTED_CALLS("Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.pulse_count_s32, 1);
	            COPY_TO_EXPECTED(ACCESS_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending), ACCESS_EXPECTED_VARIABLE(FreqInput_Manager, freq_input_filter_init_pending));
	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT(ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_72(int doIt){
	if (doIt) {
	    /* Test case data declarations */
		sCCS_Quadrature_Decode_Input_t *my_Input_Setup;
		sCCS_Quadrature_Decode_Input_t my_Input;
		 sCCS_Directional_Frequency_Inputs_t  input_ptr_Temp;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup = &my_Input;
	    my_Input_Setup->next_ptr = NULL;

	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();

	    START_TEST("72: CCS_Update_Frequency_Slow",
	               "input_quad_dec_ptr != NULL  and not pending");

	        /* Expected Call Sequence  */
	    	EXPECTED_CALLS("Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.pulse_count_s32, 1);

	            /* Checks on global data */
	            check_global_data();
	            CHECK_U_INT( ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending), FALSE);
	        END_CALLS();
	    END_TEST();
}}

void test_73(int doIt){
if (doIt) {
	    /* Test case data declarations */
		sCCS_Multiple_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Frequency_Input_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.offset = 0;
	    my_Input_Setup.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = &my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();
	    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    START_TEST("73: CCS_Update_Frequency_Slow",
	               "multiple_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1;ISOLATE_void_func_ptr_sFiltered_Data_t_p#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();

	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Raw_u32, 1);

	            /* Checks on global data */
	            check_global_data();
	        END_CALLS();
	    END_TEST();
}}

void test_74(int doIt){
if (doIt) {
	    /* Test case data declarations */
		sCCS_DG23_Directional_Frequency_Inputs_Setup_t my_Input_Setup;
		sCCS_Directional_Frequency_Inputs_t my_Input;
	    /* Set global data */
	    initialise_global_data();
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).single_frequency_input = NULL;
	    my_Input_Setup.input_ptr = &my_Input;
	    my_Input_Setup.next_ptr = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).multiple_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).pulse_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_frequency_input = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, frequency_list).paired_frequency_input = NULL;
    	ACCESS_VARIABLE(FreqInput_Manager, frequency_list).directional_dg23_frequency_input = &my_Input_Setup;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_single_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_raw_freq_buffered_slow_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager, input_quad_dec_head_ptr) = NULL;
	    ACCESS_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = TRUE;

	    /* Set expected values for global data checks */
	    initialise_expected_global_data();
	    ACCESS_EXPECTED_VARIABLE(FreqInput_Manager,freq_input_filter_init_pending) = FALSE;

	    START_TEST("74: CCS_Update_Frequency_Slow",
	               "directional_dg23_freq_list_ptr != NULL and not pending");

	        /* Expected Call Sequence  */
	        EXPECTED_CALLS("Read_Input_Data#1;Read_Input_Data#1;Read_Input_Data#1");

	            /* Call SUT */
	            CCS_Update_Frequency_Slow();
	            /* Test case checks */
	            CHECK_U_INT(my_Input.Freq_Hz_Filtered_s32, 1);
	            CHECK_U_INT(my_Input.Sensor_Status_u16, 1);
	            CHECK_U_INT(my_Input.Direction_Status_u16, 1);
	            /* Checks on global data */
	            check_global_data();
	        END_CALLS();
	    END_TEST();
}}

/*****************************************************************************/
/* Call Interface Control                                                    */
/*****************************************************************************/

/* Stub for function Configure_Input_Channel */
S32_t Configure_Input_Channel(U16_t IO_ID_u16,
                              U16_t Input_Configuration_Set,
                              Input_Config_union_t * Input_Configuration_union_p){
    REGISTER_CALL("Configure_Input_Channel");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }
    IF_INSTANCE("1") {
    	CHECK_U_INT(Input_Configuration_union_p->Frequency_struct.Frequency_Max_u32_b1_Hz,  0x1);
    	CHECK_U_INT(Input_Configuration_union_p->Frequency_struct.Frequency_Polarity_u8,  0x2);
    	CHECK_U_INT(Input_Configuration_union_p->Frequency_struct.Zero_Frequency_Timeout_u16_ms,  0x3);
    	return IO_SUCCESS;
    }
    IF_INSTANCE("2") {
    	return IO_DRIVER_ERROR;
    }
    IF_INSTANCE("3") {
        return IO_SUCCESS;
    }
    IF_INSTANCE("4") {
    	CHECK_U_INT(Input_Configuration_union_p->Frequency_struct.Physical_Input1_ID_u16 , 1);
    	CHECK_U_INT(Input_Configuration_union_p->Frequency_struct.AirGap_u8_us , 2);
    	CHECK_U_INT(Input_Configuration_union_p->Frequency_struct.AirGap_Tolerance_u8, 3);
    	CHECK_U_INT(Input_Configuration_union_p->Frequency_struct.Stand_Still_Period_u16_ms, 4);
    	return IO_SUCCESS;
    }
    IF_INSTANCE("5") {
        S32_t returnValue;
        returnValue = 0L;
        CHECK_U_INT(IO_ID_u16, 0U);
        CHECK_U_INT(Input_Configuration_Set, 1U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Frequency_Mode_u16, 7U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Zero_Frequency_Timeout_u16_ms, 0U);
        CHECK_U_CHAR((*Input_Configuration_union_p).Frequency_struct.Frequency_Polarity_u8, 85U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Physical_Input1_ID_u16, 0U);
        (*Input_Configuration_union_p).Analog_struct.Analog_Low_Pass_u32_b3_Hz = 0UL;
        return returnValue;
    }
    IF_INSTANCE("6") {
        S32_t returnValue;
        returnValue = 1L;
        CHECK_U_INT(IO_ID_u16, 0U);
        CHECK_U_INT(Input_Configuration_Set, 1U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Frequency_Mode_u16, 7U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Zero_Frequency_Timeout_u16_ms, 0U);
        CHECK_U_CHAR((*Input_Configuration_union_p).Frequency_struct.Frequency_Polarity_u8, 85U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Physical_Input1_ID_u16, 0U);
        (*Input_Configuration_union_p).Analog_struct.Analog_Low_Pass_u32_b3_Hz = 0UL;
        return returnValue;
    }
    IF_INSTANCE("7") {
        S32_t returnValue;
        returnValue = 0L;
        CHECK_U_INT(IO_ID_u16, 0U);
        CHECK_U_INT(Input_Configuration_Set, 1U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Frequency_Mode_u16, 7U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Zero_Frequency_Timeout_u16_ms, 0U);
        CHECK_U_CHAR((*Input_Configuration_union_p).Frequency_struct.Frequency_Polarity_u8, 85U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Physical_Input1_ID_u16, 0U);
        (*Input_Configuration_union_p).Analog_struct.Analog_Low_Pass_u32_b3_Hz = 0UL;
        return returnValue;
    }
    IF_INSTANCE("8") {
        S32_t returnValue;
        returnValue = 1L;
        CHECK_U_INT(IO_ID_u16, 0U);
        CHECK_U_INT(Input_Configuration_Set, 1U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Frequency_Mode_u16, 7U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Zero_Frequency_Timeout_u16_ms, 0U);
        CHECK_U_CHAR((*Input_Configuration_union_p).Frequency_struct.Frequency_Polarity_u8, 85U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Physical_Input1_ID_u16, 0U);
        (*Input_Configuration_union_p).Analog_struct.Analog_Low_Pass_u32_b3_Hz = 0UL;
        return returnValue;
    }
    IF_INSTANCE("9") {
        S32_t returnValue;
        returnValue = 0L;
        CHECK_U_INT(IO_ID_u16, 2U);
        CHECK_U_INT(Input_Configuration_Set, 1U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Frequency_Mode_u16, 10U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Forward_Pulse_u8_us, 2U);
        CHECK_U_CHAR((*Input_Configuration_union_p).Frequency_struct.Pulse_Tolerance_u8, 3U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Physical_Input1_ID_u16, 0U);
        CHECK_U_INT((*Input_Configuration_union_p).Frequency_struct.Max_Period_u16, 0U);
        (*Input_Configuration_union_p).Analog_struct.Analog_Low_Pass_u32_b3_Hz = 0UL;
        return returnValue;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Read_Input_Data_With_Error */
S32_t Read_Input_Data_With_Error(U16_t IO_ID_u16,
                                 U16_t Param_ID_u16,
                                 S32_t * Data_s32_p){
	RawFreqData_union_t value;
	REGISTER_CALL("Read_Input_Data_With_Error");


    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }

    IF_INSTANCE("1") {
    	S32_t returnValue;
    	returnValue = 0L;
    	CHECK_U_INT(IO_ID_u16, 0U);
    	CHECK_U_INT(Param_ID_u16, 1048U);
    	(*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgePolarity_u8 = 0UL;
    	(*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgeTimeStamp_u24_us = 0UL;
    	return returnValue;
    }
    IF_INSTANCE("2") {
    	S32_t returnValue;
    	returnValue = 0L;
    	CHECK_U_INT(IO_ID_u16, 0U);
    	CHECK_U_INT(Param_ID_u16, 1048U);
    	CHECK_U_INT((*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgePolarity_u8, 0UL);
    	CHECK_U_INT((*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgeTimeStamp_u24_us, 0UL);
    	(*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgePolarity_u8 = 0UL;
    	(*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgeTimeStamp_u24_us = 0UL;
    	return returnValue;
    }
    IF_INSTANCE("3") {
    	S32_t returnValue;
    	returnValue = 1L;
    	CHECK_U_INT(IO_ID_u16, 0U);
    	CHECK_U_INT(Param_ID_u16, 1048U);
    	CHECK_U_INT((*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgePolarity_u8, 0UL);
    	CHECK_U_INT((*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgeTimeStamp_u24_us, 0UL);
    	(*((RawFreqData_union_t*) Data_s32_p)).Fields_struct.EdgePolarity_u8 = 0UL;
    	return returnValue;
    }
    IF_INSTANCE("4") {
    	value.Fields_struct.EdgePolarity_u8 = 1;
    	value.Fields_struct.EdgeTimeStamp_u24_us = 2;
    	memcpy((void*) Data_s32_p, (void*) &value, sizeof(value) );
    	return IO_SUCCESS;
    }
    IF_INSTANCE("5") {
    	return IO_DRIVER_ERROR;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Stub for function Read_Input_Data */
S32_t Read_Input_Data(U16_t IO_ID_u16,
                      U16_t Param_ID_u16){
    REGISTER_CALL("Read_Input_Data");

    IF_INSTANCE("default") {
        return CANTATA_DEFAULT_VALUE;
    }
	IF_INSTANCE("1") {
		return 1;
	}

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return CANTATA_DEFAULT_VALUE;
}

/* Isolate for calls via function pointers with return type void */
/* and parameter type sFiltered_Data_t * */
void ISOLATE_void_func_ptr_sFiltered_Data_t_p(sFiltered_Data_t * data_ptr){
    REGISTER_CALL("ISOLATE_void_func_ptr_sFiltered_Data_t_p");

    IF_INSTANCE("default") {
        return;
    }
    IF_INSTANCE("1") {
    	return;
    }

    LOG_SCRIPT_ERROR("Call instance not defined.");
    return;
}

/* pragma qas cantata testscript end */
/*****************************************************************************/
/* End of test script                                                        */
/*****************************************************************************/
